<template>
    <div class="topbar d-flex justify-content-between align-items-center
     fixed-top p-2      ">
        <div class="d-flex align-items-center">
            <img src="https://startbootstrap.com/assets/img/sb-logo.svg" alt="Logo" width="30" height="30" class="me-2">
            <span class="h5">Sakshamapp</span>
        </div>

    </div>
</template>

<script>
export default {
    name: 'Navbar',
};
</script>

<style scoped>
/* Add any additional styling here */
</style>