<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('campaigns', function (Blueprint $table) {
            $table->text('status')->nullable();
            $table->integer('id')->primary();
            $table->integer('user_id');
            $table->text('type');
            $table->text('subject')->nullable();
            $table->text('message');
            $table->decimal('created_at')->nullable();
            $table->decimal('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('campaigns');
    }
};
