<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('api_logs', function (Blueprint $table) {
            $table->text('request_data')->nullable();
            $table->text('response_data')->nullable();
            $table->integer('id')->primary();
            $table->integer('user_id');
            $table->text('method');
            $table->text('url');
            $table->text('ip_address');
            $table->text('user_agent');
            $table->integer('response_status');
            $table->decimal('created_at')->nullable();
            $table->decimal('updated_at')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('api_logs');
    }
};
